# Gameplay performance observation

Probe: `perf_candidate138_idle`
Executable SHA256: `67eaa4298b7b5d048d878eda096bc0fd23f0cbcb32025da69ee6a42ff7f58ad5`

Route qualification: Completedflip00320 at558s matches baseline137 beach camera/fullhealth/ammo48of500 and ~127300 vertexrows. Normal audio, GDI, masked gathering, pool/bulk/readbackpreflight OFF. Low competing GPU activity observed through windows; inspect complete pair telemetry and natural clocks. Fixed rendered view, not active combat.
Unknown script controls logged: 0.

FPS and mean frame time use completed flips over complete host-observed report intervals.
Capture/sampling intervals are excluded; unavailable windows are shown as n/a.

| Requested seconds | Measured seconds | Flips | FPS | Mean ms/frame | Pack ms/frame | Submit ms/frame |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 560-590 | 28.27 | 641 | 22.68 | 44.10 | 4.11 | 14.68 |
| 600-630 | 28.27 | 617 | 21.82 | 45.82 | 4.12 | 14.86 |
| 650-680 | 28.37 | 619 | 21.82 | 45.83 | 4.12 | 14.71 |

Detailed synchronization totals over complete report intervals:

| Requested seconds | Host seconds | Syncs | Sync ms | Color maps / map ms / copy ms | Depth maps / map ms / copy ms | Fences / wait ms | Color alloc / reuse | Depth alloc / reuse |
| --- | ---: | ---: | ---: | --- | --- | --- | --- | --- |
| 560-590 | 29.48 | 49000 | 12652.780 | 43910 / 7727.514 / 3649.178 | 2663 / 359.146 / 395.556 | 2427 / 336.547 | 3325 / 665 | 1330 / 0 |
| 600-630 | 29.88 | 48500 | 13231.697 | 43461 / 8148.809 / 3723.366 | 2636 / 397.808 / 386.368 | 2403 / 386.898 | 3290 / 658 | 1316 / 0 |
| 650-680 | 29.68 | 48000 | 13182.249 | 43020 / 8098.283 / 3716.220 | 2609 / 378.663 / 389.150 | 2371 / 411.557 | 3257 / 651 | 1304 / 0 |

Observation limits:

- Host timestamps are report-observation times, quantized by polling/log buffering.
- No per-frame timings or frame-time percentiles are available.
- Legacy HW SYNC cumulative means are stored separately and cannot be compared as interval latency totals. New interval total times retain the logger's precision; rows without interval_ms are explicitly marked as rounded-mean-derived.
- Reports preceding monitor attachment have no recoverable host timestamps.

# Gameplay performance observation

Probe: `perf_baseline133_matched`
Executable SHA256: `43d7f8b3953a7c733eaa9acfa4826ed71ac50ef328e085d0ab0834e7db4bc36e`

Route qualification: Excluded: original verified executable stalled in movie GetStatus before gameplay; owned stop after read-only snapshot, no matching beach scene.
Unknown script controls logged: 0.

FPS and mean frame time use completed flips over complete host-observed report intervals.
Capture/sampling intervals are excluded; unavailable windows are shown as n/a.

| Requested seconds | Measured seconds | Flips | FPS | Mean ms/frame | Pack ms/frame | Submit ms/frame |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 560-590 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 600-630 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 650-680 | 0.00 | 0 | n/a | n/a | n/a | n/a |

Observation limits:

- Host timestamps are report-observation times, quantized by polling/log buffering.
- No per-frame timings or frame-time percentiles are available.
- Legacy HW SYNC cumulative means are stored separately and cannot be compared as interval latency totals. New interval total times retain the logger's precision; rows without interval_ms are explicitly marked as rounded-mean-derived.
- Reports preceding monitor attachment have no recoverable host timestamps.

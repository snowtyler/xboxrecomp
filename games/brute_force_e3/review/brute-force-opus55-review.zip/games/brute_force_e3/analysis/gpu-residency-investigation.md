# GPU residency and asynchronous completion investigation

This records source findings and a proposed design, not enabled behavior.
Candidate130 retains managed depth across ordinary completions and reuses
allocations, but still publishes coherent color at each mandatory completion.
No completion is fabricated and no readback is omitted without a coherence
mechanism.

## Current ownership and dependencies

- `xbox_memory_layout.c:nv2a_ack_thread` consumes the submitted pushbuffer and
  drives the executor. DMA_GET advances after parsing/execution, protecting
  the guest ring from premature reuse. This thread owns the D3D11 immediate
  context during gameplay.
- `nv2a_pb_scan.c` brackets frontend batches and publishes deferred semaphore
  stores only after successful real completion. Parser errors and pending
  suffix overflow suppress invalid publication. Earlier valid prefixes remain.
- `nv2a_pb_exec.c` completes work at release, flip, idle and notify boundaries.
  GPU work must finish before the guest ISR or semaphore value becomes visible.
- `nv2a_hw_raster.c:target` currently synchronizes the old backing at target
  identity/layout changes. Allocation reuse discards content validity and
  uploads the new backing. Pool entries own storage only.
- `nv2a_hw_raster.c:texture` consumes raw CPU bytes, checks exact mip/palette
  freshness, and uploads sampled textures. CPU raster/clear and feedback paths
  also depend on coherent CPU backing. Sampling an earlier render target is
  therefore a real readback dependency in the current texture path.
- Lifted `MEM8/MEM16/MEM32` operations in `recomp_types.h` are volatile native
  pointer accesses, not calls into a memory bus. Skipping color readback because
  no explicit renderer read was observed would miss ordinary guest CPU access.
- The runtime has low RAM, contiguous storage and mirror views. Any access
  tracker must cover the actual aliases of the selected backing and preserve
  existing MMIO/debug protections. Pointer-range guesses are insufficient.

## Safe incremental changes implemented

Requested color/depth staging copies are queued together before mapping.
Managed depth revisions retain native depth until a CPU dependency or target
transition requests full synchronization. Depth-only completions use an event
query: submit once if necessary, poll actual readiness, and propagate errors.
Color snapshots remain byte-exact. Direct presentation copies the matching
completed GPU color or uploads coherent CPU pixels such as decoded movies.

The current trace still shows approximately 43,000 color maps in a 30-second
paused-view interval. The completed matched candidate128 measurement spends
about 11.6s/30s in synchronization, including 6.7s map wait and 3.7s CPU copying.
Retaining color content and sampling native render targets are larger remaining
opportunities than removing the small presentation call alone.

## Requirements for selective CPU readback

1. Associate every resident color target with backing address/aliases, layout,
   native resource, CPU generation and GPU generation. Keep resource storage
   reuse distinct from preserved target content. Protect against address reuse.
2. Track actual CPU reads and writes, including lifted loads and host helpers.
   A Windows page-protection/VEH approach avoids adding a call to every lifted
   load, but must account for shared pages, existing protection, aliases and
   renderer-owned accesses. It must restore protection on eviction/shutdown.
3. On a guest access to dirty resident data, request synchronization from the
   D3D11 owner thread, wait for real availability, publish exact bytes, then
   retry the original access. Reads of adjacent bytes on shared pages may
   conservatively synchronize. Writes must first preserve prior GPU writes and
   then invalidate native content before its next use.
4. Service requests even when the guest submits no new commands. Audit waits
   and held locks/IRQL so a faulting caller cannot block the context owner or
   prevent a required guest interrupt. Do not run the immediate context from
   arbitrary faulting CPU threads.
5. Native sampling of resident render targets needs matching SRVs and explicit
   hazards, layout/format/mip handling, CPU-write invalidation and feedback
   semantics. Raw texture freshness checks must not silently read stale CPU
   storage. Unsupported cases retain the coherent fallback.
6. Test CPU reads/writes before and after fences, partial pages and aliases,
   pitched BGRA/RGB565, color/depth target changes, mips, failure/recovery,
   concurrent faults, eviction, shutdown, and exact presented pixels. Then run
   normal-audio combat/death/replay/resumed controls against the exact candidate.

## Requirements for asynchronous guest completion

A pending completion must capture its ordered GPU frontier and guest destination
before later commands overwrite renderer state. Event readiness can be polled
without blocking the context owner. A staging-copy ring can provide ordered
snapshots when CPU publication is required. Queue pressure must wait for actual
completion rather than discard entries or invent success.

Publishing a release must preserve prefix ordering, required color/depth
coherence, nested pushbuffer behavior, subsequent CPU writes and guest ISR
ordering. Later parser/device failures must not invalidate earlier completed
prefixes or publish a failed suffix. CPU accesses may need to drain the relevant
frontier. A borrowed pointer to the current target cannot represent an earlier
pending completion after the target changes.

The earlier attempt to defer mandatory release waits did not pass gameplay and
was reverted. It is not evidence that all asynchronous implementations fail,
but it is insufficient grounds to bypass the wait. A completion queue plus
coherence/access tracking and prefix regression evidence is required before
enabling this path. Current candidates preserve mandatory release completion.

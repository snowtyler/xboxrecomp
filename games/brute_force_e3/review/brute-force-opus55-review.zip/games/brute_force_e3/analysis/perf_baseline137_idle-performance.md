# Gameplay performance observation

Probe: `perf_baseline137_idle`
Executable SHA256: `43d7f8b3953a7c733eaa9acfa4826ed71ac50ef328e085d0ab0834e7db4bc36e`

Route qualification: Completed700.43s watchdog3. Completedflip00331 at558s matches paused starting beach/fullhealth/ammo48of500. All three timed windows have low competing GPU Engine activity; NVIDIA utilization/clocks recorded during windows. Fixed rendered view, not active combat.
Unknown script controls logged: 0.

FPS and mean frame time use completed flips over complete host-observed report intervals.
Capture/sampling intervals are excluded; unavailable windows are shown as n/a.

| Requested seconds | Measured seconds | Flips | FPS | Mean ms/frame | Pack ms/frame | Submit ms/frame |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 560-590 | 28.36 | 561 | 19.78 | 50.56 | 5.70 | 14.84 |
| 600-630 | 28.46 | 574 | 20.17 | 49.59 | 5.70 | 15.08 |
| 650-680 | 26.46 | 557 | 21.05 | 47.50 | 5.66 | 14.66 |

Observation limits:

- Host timestamps are report-observation times, quantized by polling/log buffering.
- No per-frame timings or frame-time percentiles are available.
- Legacy HW SYNC cumulative means are stored separately and cannot be compared as interval latency totals. New interval total times retain the logger's precision; rows without interval_ms are explicitly marked as rounded-mean-derived.
- Reports preceding monitor attachment have no recoverable host timestamps.

# Performance investigation — candidate verification pending

The launcher's verified executable remains unchanged (SHA-256
`43d7f8b3953a7c733eaa9acfa4826ed71ac50ef328e085d0ab0834e7db4bc36e`).
No performance candidate is approved for replacement yet. Original assets are
read-only; NVIDIA settings, commits and publication are outside this work.

## Current baseline

`perf_baseline124` exercised movement, firing, damage and death with normal
audio. Its timed views differed from candidate128 because a wall-clock input
route advances through different camera/tutorial states at different speeds.
Those raw timing differences do not establish a performance gain.

`perf_baseline129_paused` completed 700.91 seconds against the exact verified
executable. Completed flip00319 at approximately 558 seconds shows Options
paused over the starting beach camera, full health and ammo48/500. Report00346
near600 seconds shows the same view. The route has no movement or fire inputs.
It measures a fixed rendered view with normal audio, not active combat.

| Window (seconds) | Measured seconds | Mean frame time | FPS | Pack/frame | Submit/frame |
| --- | ---: | ---: | ---: | ---: | ---: |
| 560–590 | 28.37 | 51.77 ms | 19.31 | 5.71 ms | 14.92 ms |
| 600–630 | 28.37 | 56.28 ms | 17.77 | 5.78 ms | 15.29 ms |
| 650–680 | 28.38 | 46.52 ms | 21.50 | 5.70 ms | 14.73 ms |

`perf_candidate129_paused_gdi` completed 700.58s against exact candidate128
bytes. Its completed capture and report00339 match the baseline camera, HUD
and Options state. Both average approximately 127,300 vertex rows/frame.

| Window (seconds) | Baseline frame time | Candidate128 frame time |
| --- | ---: | ---: |
| 560–590 | 51.77 ms | 45.46 ms |
| 600–630 | 56.28 ms | 45.98 ms |
| 650–680 | 46.52 ms | 45.60 ms |

Across complete intervals, total host time divided by completed flips is
51.21 ms/frame baseline versus 45.69 ms/frame candidate, about 11% lower frame
time in this view. This is one paired run with visible baseline variation;
it does not establish a general combat or campaign improvement. Candidate128
still spent approximately 11.6s of each 30s interval in synchronization,
including about 6.7s color-map wait and 3.7s color copying.

Values use completed flips over complete host-observed report intervals.
Sampling and completed-frame capture intervals are excluded. There are no
per-frame percentiles. GPU timing/trace and audio settings match.
`perf_candidate130_paused_gdi` is measuring the additional pool change against
these same windows.

Candidate130 subsequently completed 700.31s. Completed flip00333 at558.7s
matches the paused scene; report00338 is a partially drawn frame and is not
rendering evidence. The measured vertex rows remain approximately127,300/frame.
Its mean windows were45.40/47.59/46.07ms, aggregate46.34ms/frame. Warmed-up color
and depth allocations both fell to zero, but frame time did not improve over
candidate128's45.69ms. The pool is disabled for the next candidate evaluation.
The single paired runs do not establish a small regression either; allocation
reduction alone is not a performance conclusion.

## Changes under evaluation

- Color and requested depth copies are submitted together before either map.
- Same-sized target allocations are reused after synchronizing the old backing.
- Managed depth stays native at flips, with real GPU completion before guest
  semaphore/interrupt publication and full readback on CPU depth use/transition.
- Linear single-level BGRA textures use a bounds-checked direct upload while
  retaining exact byte comparisons for freshness.
- Candidate131 copies tightly packed BGRA readback and its exact CPU snapshot
  in contiguous spans when GPU and CPU pitches match. Padded/RGB565 rows keep
  the existing path. The refreshed raster fixture passes retained/reload/pool-
  disabled modes (293 draws/103 syncs plus recreation), including a wide target,
  last-pixel copy and CPU edit. Performance benefit is not yet isolated.
- Optional direct D3D11 swap-chain presentation shares the rasterizer's device
  and context owner. Completed matching GPU color is copied directly; coherent
  CPU movie pixels use an upload. The launcher has not enabled this option.
- Candidate130 adds a bounded allocation pool across target dimensions. The
  pool retains storage only; guest identity, CPU snapshots and depth revisions
  are discarded. New backing is uploaded before use. Eight entries per plane
  with a 4 MiB logical texture-size cap per entry bound retained texture storage
  to 64 MiB plus active targets and driver overhead. Oversized/incomplete
  allocations use destruction. `RECOMP_HW_TARGET_POOL_DISABLE=1` permits A/B
  measurement. Native tests for reuse/eviction and shutdown/recreation passed
  in retained-color, forced-color-reload, and pool-disabled modes (291 draws /
  101 syncs plus a fresh-device draw). See `test-raster130-pool-retained.log`,
  `test-raster130-pool-reload.log`, and `test-raster130-pool-disabled.log`.
  The refreshed real GPU semaphore test also passed (`test-fences130-gpu.log`).
  Gameplay/replay verification is pending.

Candidate128's earlier 500–530-second interval recorded 3,473 color allocations
and 1,946 depth allocations in about 29.67 seconds. Its sync total was12.218s,
including7.358s color-map waits and3.543s color copying. These are evidence for
allocation pooling and continued readback work, not attribution of all remaining
frame time. More selective readback and asynchronous guest completion require
an explicit coherence/ordering design; mandatory release waits remain in place.

## Correctness gates

Candidate127 stalled with direct presentation enabled and disabled. Candidate128
restored the mandatory completion wait at every semaphore release and passed
the earlier first-playthrough stalls, combat, damage and death, then stalled in
a replay movie. None of these runs permits promotion.

The replay sample shows the main thread polling DirectSound GetStatus through
`0033EC96 → 0033E243 → 0034528E`; Bink's caller at386483 waits for stopped status.
The GPU thread was idle. A read-only snapshot showed the graphics event signaled.
The SDK status is derived from voice-object flags, so a future reproduction must
inspect the actual voice-off command, RAM notification and interrupt/status
update rather than force a stopped result. A possible concurrent `set_irq`
flag-clear race in the APU is a source hypothesis, not a confirmed diagnosis.
No APU behavior has been changed for this hypothesis.

`inspect_guest.py` now resolves APU field offsets from the executable's PDB,
selects the process's oldest thread by creation time, and reads guest registers,
voice flags, native APU interrupt state and both memory aliases of voice/notifier
records. Automatic thread selection and APU field offsets were validated on
the owned baseline and candidate. Future replay probes capture it at1360s.
Snapshots do not suspend the process or modify memory and are not atomic.

`perf_candidate131_gpu_replay` is live on exact131 bytes with normal audio,
direct presentation enabled, and the pool explicitly disabled. It first repeats
the matched paused windows, resumes at700s, then exercises combat/death/replay
and movement/firing after replay. Scheduled completed-flip captures cover these
stages; read-only guest/APU inspection runs at1640s. This run is pending and is
not a promotion gate result. Refreshed native swap-chain tests passed24,064
byte-exact pixels plus resize/minimize/restore, focus/keyboard and owned close
(`test-framebuffer-gpu131.log`, zero failures; expected injected resize failure).

Its completed flip00464 matches the paused comparison scene. The direct-
presentation plus bulk-copy windows were50.84/52.62/46.81ms; this combined path
did not improve over the GDI candidate128 measurement. These changes are now
opt-in for subsequent candidates rather than assumed defaults. The pool is
also opt-in (`RECOMP_HW_TARGET_POOL=1`), with the disable switch retained.

Candidate131 has verified firing/damage/movement (completed flip00616, ammo22/500),
death (flip00754), replay confirmation (flip00993), restarted intro (report01067),
returned HUD with fresh health/ammo48/500 (flip01185), and resumed movement and
firing after replay (flip01272, moved camera/player and ammo27/500). Normal
source PCM continues. Terminal stability/closure gates are still pending; the
verified artifact has not been replaced.

Candidate131 subsequently completed2000.26s (intentional watchdog3), with no
stalled flip progression. Later flip01502 shows a second Squad Killed after
resumed combat. The automatic1640s inspection reports no pending APU interrupt
and no raised IRQL. This establishes this candidate's replay/control result;
the earlier stop-status race remains unconfirmed and the APU is unchanged.

## Candidate132 prepared

Candidate132 adds a conservative vertex-input gather mask derived from the
same A/B/C multiplexers and V index as the HLSL translator. Every referenced
attribute is still fetched; constants and registers do not request input
attributes. Invalid/missing-END programs gather all attributes. The raw vertex
layout and draw submissions are unchanged; CPU fallback still gathers its
full inputs. `RECOMP_HW_VSH_GATHER_ALL=1` provides an A/B control. Actual gather
counts are logged separately from the unchanged vertex-row count.

The GPU/CPU fixture passed148 configurations /9,472 inputs with all sixteen
input indices, independent A/B/C-only cases, NaNs in unreferenced GPU inputs,
full CPU references, and exact CPU output equality after pruning. See
`test-vertex132-input-mask-expanded.log`. Gameplay/timing verification remains.

`RECOMP_HW_READBACK_FENCE=1` opts into a real event query after requested staging
copies and before Map. It submits once if needed and waits for actual S_OK;
it still maps/copies all CPU bytes and preserves mandatory guest release waits.
This is readiness preflight, not asynchronous guest semaphore publication.
Real color/depth coherence, recreation and semaphore tests passed with the
option (`test-raster132-event-pool-bulk.log`, `test-raster132-event-reload.log`,
`test-fences132-event-gpu.log`). Default legacy mapping also passed
(`test-raster132-default.log`). No gameplay performance benefit is claimed yet.

The title measurement with preflight enabled then recorded50.01/52.33/52.24ms
in the matched windows. Gathering fell to approximately4.0ms/frame, but waiting
on events consumed11.25–11.98s/30s and total sync cost increased. It did not
improve frame time. This configuration was intentionally stopped at1179.08s
(owned stop flag, exit1/stopped=true) after the measured regression; it is not
a completed replay gate. Default real-GPU semaphore publication also passed
(`test-fences132-default-gpu.log`).

`perf_candidate132_default_replay` now tests the same exact132 bytes with normal
audio, masked gathering enabled, legacy mapping, GDI presentation, and pool/
bulk/preflight disabled. It repeats the fixed view followed by the complete
combat/death/replay/resumed-control route. No promotion is authorized by its
in-progress state. Source/readback/query flags and artifact hashes are recorded
in each probe's process manifest and performance report.

During this run, global GPU utilization rose to64% versus the earlier6% reference.
Host GPU Engine counters attributed approximately41.3% 3D utilization to
`penumbra.exe` and8.0% to the owned Brute Force candidate. See
`perf132-gpu-contention.json`. The default run's69.09/58.80/74.21ms matched-scene
windows are confounded by materially different GPU load and cannot be used as
a before/after regression claim. The earlier preflight run also lacks matching
GPU telemetry, so its apparent regression needs qualification rather than
causal attribution. Correctness captures remain usable: completed00602 shows
movement/fire/damage with ammo24/500;00726 shows Squad Killed. A matched-load
before/after measurement remains required before a final performance claim.

Further completed captures verify132default replay:00929 Saving/intro start,
01125 returned HUD with full health and ammo48/500,01209 resumed movement/fire
with ammo28/500 and damage after replay. Source PCM continues. Terminal stability
and exact launcher closure are pending; the verified executable is untouched.

Refreshed pushbuffer control, native keyboard/window closure and XAudio2
ownership/mute regressions passed (`test-pushbuffer132-final.log`,
`test-keyboard132-final.log`, `test-xaudio2132-final.log`). The launcher-owned
window/child closure check is prepared in `test_launcher.ps1`, to run after
the current gameplay process is terminal.

Required before replacement: comparable before/after evidence, rendering and
coherence regressions, real semaphore/interrupt ordering, normal audio, combat,
death, replay, returned HUD, resumed movement/firing, and keyboard/window closure.
The exact tested executable/PDB must be promoted only after all gates pass.

## Final candidate correctness and matched-load repeat

The exact candidate132 default run completed 2000.23 seconds with normal audio
(intentional watchdog exit3, no host timeout or explicit stop). Completed flips
00602/00726/00929/01125/01209 establish movement, firing, damage, death, replay,
returned HUD and resumed movement/firing. The 1640s read-only snapshot shows no
pending APU interrupt and IRQL0. Earlier pending statements above are superseded
by this terminal result. No APU behavior was changed for performance work.

The updated normal launcher also passed against these exact bytes
(`test-launcher132-final.json`): visible owned window, WM_CLOSE, child exit and
launcher exit0. Parent experiment flags were deliberately set and cleared by
the launcher. The original verified executable/PDB have hash-verified backups
under `verified122-backup` and remain unchanged in the normal build location.

The user requested continuing correctness checks while waiting for GPU load to
drop. Read-only counters subsequently showed the competing heavy workload had
dropped. `perf_baseline133_matched` repeats the original executable's fixed
paused route with continuous host GPU Engine telemetry. Candidate132 will run
the same route sequentially. The paired result remains pending; prior contended
candidate132 frame times are excluded from a performance claim.

Baseline133 failed to reach the beach: its original verified executable stopped
progressing in the intro movie. The read-only stall snapshot shows guest stack
33E249/33ECAF/386483 (the same DirectSound/Bink status polling path), APU status
0x11 and IRQ line1, with IRQL0. It was intentionally stopped at512.45s and is
excluded from timing. This is a reproduction on the original bytes, not proof
of a graphics optimization regression or a confirmed APU root cause. Baseline134
retries the same script. The GPU recorder now records transient invalid-counter
errors and continues with valid Status0 samples; baseline133's observation gap
is preserved rather than treated as zero utilization.

Baseline134 exited0 at413.27s before the measurement windows; the reason is
unverified, so it is excluded. Baseline135 completed700.29s (watchdog3), with
completed flip00319 at558s matching the paused starting beach, full health and
ammo48/500. Its windows measured61.50/67.46/68.72ms. Continuous GPU observations
show another process consuming roughly30–50% of the same adapter's 3D engine,
so these are contended-load observations, not an idle baseline. Per-window
GPU statistics and report totals are reproduced by `compare_performance.py`;
`perf135-vs132-contended-observation.json` is observational only, since132 lacks
continuous matching telemetry. No promotion is justified by this comparison.

The user requested waiting for load to drop. `perf_idle136` now records read-only
GPU observations without a game test running. Candidate132 remains unchanged
and separately named. A fresh idle-load baseline/candidate pair is still needed.

At20:38 local, the competing Penumbra process15432's heavy GPU activity dropped.
Five successive low-load observations were recorded by `perf_idle136`; its
watcher then ended with an explicit `observation_ready` record (not a game-test
result). `perf_baseline137_idle` started with the original executable and fresh
telemetry. Its current run remains pending. The next sequential candidate is
the unchanged132 executable with the identical PausedView700 script. Continued
telemetry must establish that the timed windows remained comparable.

Baseline137 completed700.43s (watchdog3). Completed00331 at558s matches the paused
beach/full health/ammo48/500. Windows50.56/49.59/47.50ms aggregate49.22095ms, with
approximately127,300 vertex rows/frame. Timed-window GPU Engine samples show
low competing activity (individual external peaks <=1.3%), no counter errors
and maximum sample gaps6.6s. A transient Chrome burst earlier in warmup was
outside these windows. `monitor_nvidia.ps1` records read-only utilization,
memory activity, graphics/memory clocks, power and temperature. NVIDIA queries
all succeeded during the windows. Graphics clocks varied naturally1020–2265MHz,
memory810–10501MHz; no settings were changed. These observations qualify the
measurement rather than assuming globally idle hardware or fixed clocks.

`perf_candidate138_idle` now runs the exact132 bytes sequentially with the same
PausedView700 script and both GPU Engine/NVIDIA recorders. Performance and scene
comparison remain pending. `compare_performance.py` includes per-window NVIDIA
metric ranges and means; the historical128 observation only validates reporting
and does not replace the new candidate comparison.

Final audit identified one material configuration gap: the old verified title
route had GPU trace/timing disabled, whereas candidate132's completed33-minute
route enabled them. Those queries can alter waiting/scheduling. Before promotion,
repeat the same exact candidate's full route with normal graphics flags.
`performance.ps1 -NormalGraphics -PausedReplay` clears GPU trace/timing and timed
windows, disables CPU sampling/measurement, and retains normal audio plus
source-PCM counters, scheduled captures and the read-only1640s inspection.
The script parses successfully; this mode is pending after candidate138 ends.
No runtime source or executable bytes changed for this harness addition.

Candidate138 completed700.48s, watchdog3 with no timeout/stop. Completed00320
matches baseline137's paused beach/full health/ammo48/500; rows remain about
127,300/frame. The final paired report records49.22095→45.23633ms (8.09537% lower
frame time), with all three windows improved:50.56→44.10,49.59→45.82,47.50→45.83ms.
Both runs have low competing3D activity, no timed-window counter/NVIDIA errors,
and overlapping naturally varying clock ranges. Packing falls5.7→4.1ms/frame;
submission remains about14.7ms. This is one fixed rendered view, not an active
combat/campaign speedup or fixed-clock measurement.

Current detailed sync intervals spend12.65–13.23s/29.48–29.88s synchronizing,
including7.73–8.15s color map waits and3.65–3.72s copying, with43,020–43,910 color
maps. CPU samples137/138 are retained; ambiguous nearest driver-export names
are not interpreted as precise driver-function costs. Timestamp sampling is
bounded (a logged dropped count means profiling samples, not skipped draws).
Current interval data replace119/118 historical traces for the final bottleneck
claim. Submission and sync timings may overlap and are not additive.

`final_candidate139_normal` is live on exact132 bytes with GPU trace/timing and
all experiment flags null, normal audio, no CPU sampler/measurement, and the
full PausedReplay2000 route. Its process manifest confirms those flags and no
GPU timestamp lines have appeared. Scheduled gameplay captures and1640s
read-only inspection must pass before exact-byte promotion. The old normal
executable/PDB remain unchanged and backed up.

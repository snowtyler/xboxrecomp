# Gameplay performance observation

Probe: `perf_candidate132_default_replay`
Executable SHA256: `67eaa4298b7b5d048d878eda096bc0fd23f0cbcb32025da69ee6a42ff7f58ad5`

Route qualification: Completed 2000.23s normal audio; completed flips prove combat, damage, death, replay, returned HUD and resumed movement/firing. Fixed-view timing confounded by concurrent GPU workload; excluded from before/after.
Unknown script controls logged: 0.

FPS and mean frame time use completed flips over complete host-observed report intervals.
Capture/sampling intervals are excluded; unavailable windows are shown as n/a.

| Requested seconds | Measured seconds | Flips | FPS | Mean ms/frame | Pack ms/frame | Submit ms/frame |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 560-590 | 28.67 | 415 | 14.47 | 69.09 | 4.49 | 16.01 |
| 600-630 | 26.46 | 450 | 17.01 | 58.80 | 4.35 | 15.23 |
| 650-680 | 28.57 | 385 | 13.48 | 74.21 | 4.40 | 15.71 |

Detailed synchronization totals over complete report intervals:

| Requested seconds | Host seconds | Syncs | Sync ms | Color maps / map ms / copy ms | Depth maps / map ms / copy ms | Fences / wait ms | Color alloc / reuse | Depth alloc / reuse |
| --- | ---: | ---: | ---: | --- | --- | --- | --- | --- |
| 560-590 | 29.78 | 32000 | 18084.900 | 28737 / 13729.186 / 2655.569 | 1734 / 693.318 / 265.720 | 1529 / 591.790 | 2157 / 431 | 864 / 0 |
| 600-630 | 29.68 | 38000 | 16332.148 | 34132 / 11599.743 / 2956.296 | 2054 / 599.875 / 299.148 | 1814 / 712.992 | 2562 / 512 | 1026 / 0 |
| 650-680 | 29.47 | 29500 | 18965.643 | 26489 / 14533.126 / 2275.530 | 1599 / 784.100 / 235.518 | 1412 / 1004.658 | 1990 / 398 | 796 / 0 |

Observation limits:

- Host timestamps are report-observation times, quantized by polling/log buffering.
- No per-frame timings or frame-time percentiles are available.
- Legacy HW SYNC cumulative means are stored separately and cannot be compared as interval latency totals. New interval total times retain the logger's precision; rows without interval_ms are explicitly marked as rounded-mean-derived.
- Reports preceding monitor attachment have no recoverable host timestamps.

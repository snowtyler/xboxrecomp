# Gameplay performance observation

Probe: `perf150_irq_title_qf_control_2`
Executable SHA256: `07942cb7968bbda21050c4bf613e7a01b3e51d0398bc58048c99cec8f68fa9e7`

Route qualification: Confirm the scripted route against completed gameplay captures.
Unknown script controls logged: 0.

FPS and mean frame time use completed flips over complete host-observed report intervals.
Capture/sampling intervals are excluded; unavailable windows are shown as n/a.

| Requested seconds | Measured seconds | Flips | FPS | Mean ms/frame | Pack ms/frame | Submit ms/frame |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 500-530 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 600-615 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 640-660 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 710-730 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 750-770 | 0.00 | 0 | n/a | n/a | n/a | n/a |
| 800-830 | 0.00 | 0 | n/a | n/a | n/a | n/a |

Observation limits:

- Host timestamps are report-observation times, quantized by polling/log buffering.
- No per-frame timings or frame-time percentiles are available.
- Legacy HW SYNC cumulative means are stored separately and cannot be compared as interval latency totals. New interval total times retain the logger's precision; rows without interval_ms are explicitly marked as rounded-mean-derived.
- Reports preceding monitor attachment have no recoverable host timestamps.
